from datetime import datetime, timedelta, date
from os.path import join
from random import random

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split, cross_val_score
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator
from ta.volatility import BollingerBands
from tensorflow.python.ops.confusion_matrix import confusion_matrix

from src.DwxClient import DwxClient


class TickProcessor(object):
    X_train: object
    y_train: object
    X_test: object
    y_test: object
    model = None

    def __init__(self,
                 sleep_delay=0.005,  # 5 ms for time.sleep()
                 max_retry_command_seconds=10,  # retry to send to commend for 10 seconds if not successful.
                 verbose=True, db=None, metatrader_dir_path: str = ''
                 ):

        self.open_test_trades = True
        self.trade_day = None
        self.use_trade_day = True
        self.symbols = ['EURUSD', 'USDJPY', 'USDCAD', 'USDCHF', 'USDNOK', 'USDSEK', 'USDTRY']
        self.metatrader_dir_path = metatrader_dir_path
        self.takeprofit = 0.01
        self.signal = 1
        self.stoploss = 0.01
        self.bar_data = None
        self.orderprofit_ = 0.9
        self.profits = 0
        self.MM_Martingale_Start = 0.01
        self.MM_Martingale_LossFactor = 2
        self.MM_Martingale_RestartLoss = True
        self.MM_Martingale_RestartProfit = True
        self.MM_Martingale_ProfitFactor = 4
        self.MagicNumber = 0

        self.order_id = 0
        self.history_data_df = pd.DataFrame()
        self.signal_on_tick = None
        self.historic_trades = None
        self.historic_trades_df = None
        self.lot_size = self.get_lot_size()

        self.bar_data_count = None
        self.bar_data_count = 0
        self.metatrader_dir_path: str = metatrader_dir_path

        self.tick_data = None
        self.symbol = 'EURUSD'

        self.bid = 0.0

        self.ask = 0.0
        self.db = db
        self.da = None
        self.bar_data_df = pd.DataFrame(columns=['time', 'symbol', 'time_frame', 'open', 'high', 'low', 'close',
                                                 'volume'])
        self.verbose = verbose
        self.sleep_delay = sleep_delay
        self.max_retry_command_seconds = max_retry_command_seconds

        self.last_open_time = datetime.utcnow()
        self.last_modification_time = datetime.utcnow()

        self.dwx = DwxClient(self, metatrader_dir_path=self.metatrader_dir_path, verbose=verbose, db=self.db,
                             time_frame='H1',
                             symbols=self.symbols)

        self.dwx.subscribe_symbols(self.symbols)
        self.time_frame = 'H1'
        for i in self.symbols:
            symbo = [i, self.time_frame]
            self.dwx.subscribe_symbols_bar_data([symbo])

            start: int = int(str((datetime.utcnow() - timedelta(days=30)).timestamp()).split('.')[0])
            end: int = int(datetime.utcnow().timestamp())

            # last 60 days
            self.dwx.get_historic_data(i, self.time_frame, start, end)

        # account information is stored in self.dwx.account_info.
        print("Account info:", self.dwx.account_info.__str__())

        # Start DWX server
        self.dwx.start()

        # wait for stop event

    def on_bar_data(self,
                    symbol,
                    time_frame,
                    data: pd.DataFrame = None
                    ):

        if self.verbose:
            print(f'on_bar_data: {symbol} {time_frame} {data}')

    def on_historic_data(self, symbol: str = '', time_frame: str = '', data: list = None):

        history = pd.DataFrame(data, columns=['time', 'symbol', 'time_frame', 'open', 'high', 'low', 'close', 'volume'])

        if self.verbose:
            history['symbol'] = symbol
            history['time_frame'] = time_frame
            history.to_csv(self.dwx.path_historic_data, index=True,
                           header=True)
            print('historic number' + str(self.bar_data_count) + " " + str(history))

    def on_historic_trades(self, symbol: str = '', time_frame: str = '', trades: list = None):

        print(f'historic_trades: {len(self.dwx.historic_trades)}')
        self.dwx.historic_trades = pd.DataFrame(trades, columns=['time', 'time_frame', 'symbol', 'order_id',
                                                                 'price', 'amount', 'comment', 'expiration',
                                                                 'order_type', 'stoploss', 'takeprofit'])
        if self.verbose:
            self.dwx.historic_trades['symbol'].values = symbol
            self.dwx.historic_trades['time_frame'].values = time_frame
            self.dwx.historic_trades.to_csv(join(self.dwx.path_historic_trades),

                                            index=False, header=True)

            print('historic_trades number' + str(self.bar_data_count) + " " + str(self.dwx.historic_trades))

    def on_message(self, message):

        if message['type'] == 'ERROR':
            print(message['type'], '|', message['error_type'], '|', message['description'])
            self.dwx.server_status['server_status'] = 'ERROR'
            self.dwx.server_status['error_type'] = message['error_type']
            self.dwx.server_status['description'] = message['description']
        elif message['type'] == 'INFO':
            print(message['type'], '|', message['message'])
            self.dwx.server_status['server_status'] = 'OK'
            self.dwx.server_status['message'] = message['message']

    # triggers when an order is added or removed, not when only modified.
    def on_order_event(self):
        print(f'on_order_event. open_orders: {len(self.dwx.open_orders)} open orders')
        self.dwx.server_status['open_orders'] = len(self.dwx.open_orders)
        self.dwx.server_status['server_status'] = 'OK'

    def on_tick(self, symbol=None, tick_data=None, bar_data=None):
        """
    Handles trading logic on each tick.

    Args:
        use_trade_day (bool): Flag indicating whether to check if trading is allowed on the current day.
        market_data (pd.DataFrame): DataFrame containing market data.
        bar_data: Additional bar data for signal generation.

        :param tick_data:
    """

        self.dwx.server_status['server_status'] = 'OK'
        print(f'on_tick. tick_data: {tick_data.__str__()}')
        self.dwx.server_status['tick_data'] = tick_data

        self.dwx.server_status['last_modification_time'] = datetime.utcnow()
        self.dwx.server_status['last_open_time'] = self.last_open_time

        # Extract symbol from market_data
        use_trade_day = self.use_trade_day

        bid = tick_data[symbol]['bid']
        ask = tick_data[symbol]['ask']
        if use_trade_day:
            # Check if trading is allowed today
            self.trade_day = self.trade_days(ea_stop_day='Friday',
                                             ea_start_day='Sunday',
                                             ea_start_time='09:00:00',
                                             ea_stop_time='23:30:00'

                                             )
            if not self.trade_day:
                print('Trading is not allowed today: ' + date.today().strftime('%Y-%m-%d %H:%M:%S'))
                self.dwx.server_status['server_status'] = 'ERROR'
                self.dwx.server_status['error_type'] = 'TRADE_NOT_ALLOWED today ' + date.today().strftime(
                    '%Y-%m-%d '
                    '%H:%M:%S')
            else:
                print('Trading is allowed today!')
                self.dwx.server_status['server_status'] = 'OK'
                self.dwx.server_status['info'] = 'Trading is allowed today!'

            self.signal_on_tick =  self.get_signal(data=bar_data)

            now = datetime.utcnow()

            print('on_tick:', now, symbol, bid, ask)

            # to test trading.
            # this will randomly try to open and close orders every few seconds.
            if self.open_test_trades:
                if now > self.last_open_time + timedelta(seconds=3):
                    self.last_open_time = now

            lot = self.lot_size
            if self.signal_on_tick == 1:
                order_type = 'buystop'
                price = bid

                self.dwx.open_order(symbol=symbol, order_type=order_type,
                                    price=price, lots=lot, stop_loss=price-0.001, take_profit=price+0.001,
                                    magic=random() * 0.001,
                                    comment='ZONES ' + order_type.__str__() + 'TRADE @' + now.__str__())

            if random() > 0.5:
                if now > self.last_modification_time + timedelta(seconds=10):
                    self.last_modification_time = now
                    if self.signal_on_tick == -1:
                        order_type = 'sellstop'

                        price = ask

                        self.dwx.open_order(symbol=symbol, order_type=order_type,
                                            price=price, lots=lot, stop_loss=0.01, take_profit=price-0.01,
                                            magic=random() * 0.001,
                                            comment='ZONES ' + order_type + ' TRADE @' + now.__str__())

            if now > self.last_modification_time + timedelta(seconds=10):
                self.last_modification_time = now

            for ticket in self.dwx.open_orders.keys():
                self.dwx.close_order(ticket, lots=0.1)

            if len(self.dwx.open_orders) >= 10:
                self.dwx.close_all_orders()
            # self.dwx.close_orders_by_symbol('GBPUSD')
            # self.dwx.close_orders_by_magic(0)

    def get_lot_size(self):
        i = 0.001
        while i < 0.02:
            i += 0.001+random() *0.005
            if i > 0.02:
                i = 0.02

        return 0.02 + i

    def trade_days(self, set_trading_days='yes', ea_start_day='Monday', ea_stop_day='Friday', ea_start_time='00:00',
                   ea_stop_time='23:59'):
        if set_trading_days == 'no':
            return True
        start_day = 0
        stop_day = 0
        if ea_start_day == 'Monday':
            star_day = 1

        elif ea_start_day == 'Tuesday':
            star_day = 2

        elif ea_start_day == 'Wednesday':
            star_day = 3

        elif ea_start_day == 'Thursday':
            star_day = 4

        elif ea_start_day == 'Friday':
            star_day = 5

        elif ea_start_day == 'Saturday':
            star_day = 6

        elif ea_start_day == 'Sunday':
            star_day = 7

        if ea_stop_day == 'Monday':
            stop_day = 1

        if ea_stop_day == 'Tuesday':
            stop_day = 2

        if ea_stop_day == 'Wednesday':
            stop_day = 3

        if ea_stop_day == 'Thursday':
            stop_day = 4

        if ea_stop_day == 'Friday':
            stop_day = 5

        if ea_stop_day == 'Saturday':
            stop_day = 6

        if ea_stop_day == 'Sunday':
            stop_day = 7

        else:
            stop_day = 0

        today = datetime.today().weekday()

        start_time = datetime.strptime(ea_start_time, "%H:%M:%S").time()
        stop_time = datetime.strptime(ea_stop_time, "%H:%M:%S").time()

        current_time = datetime.now().time()

        if start_day < stop_day:
            if start_day < today < stop_day:
                return True
            elif today == start_day:
                if current_time >= start_time:
                    return True
                else:
                    return False
            elif today == stop_day:
                if current_time < stop_time:
                    return True
                else:
                    return False
        elif start_day > stop_day:
            if start_day < today or today < stop_day:
                return True
            elif today == start_day:
                if current_time >= start_time:
                    return True
                else:
                    return False
            elif today == stop_day:
                if current_time < stop_time:
                    return True
                else:
                    return False
        elif start_day == stop_day:
            start_datetime = datetime.combine(datetime.today().date(), start_time)
            stop_datetime = datetime.combine(datetime.today().date(), stop_time)

            if start_time < stop_time:
                if start_datetime <= datetime.now() <= stop_datetime:
                    return True
                else:
                    return False
            else:
                if start_datetime <= datetime.now() or datetime.now() <= stop_datetime:
                    return True
                else:
                    return False

        return False

    def get_signal(self, data=None):
        """
         Get the buy and sell signal for a given symbol
        :param data:
        :return:
        """


        if data is None or data.empty:
            self.dwx.server_status['server_status'] = 'ERROR'
            self.dwx.server_status['error_type'] = 'NO_TICK_DATA'
            print('get_signal. data is None or len(data) == 0')
            return 0



        if data.values is not None :

            # Create a DataFrame from the dictionary

            serie = pd.Series(data=data['close'], index=data['time'])
            macd_signal = MACD(close=serie, window_fast=12, window_slow=26, window_sign=9).macd_signal()
            if macd_signal.values is not None or macd_signal.empty:
                print( 'macd'  , macd_signal.__str__())
                return 0

            print('macd ' + macd_signal.__str__())

            macd_signal.fillna(method='ffill', inplace=True)
            macd_signal.fillna(method='bfill', inplace=True)

            sma_signal = SMAIndicator(close=serie, window=24).sma_indicator()
            sma_signal.fillna(method='ffill', inplace=True)

            sma_signal.fillna(method='bfill', inplace=True)
            print('sma_signal' + sma_signal.__str__())
            if sma_signal.values is not None or sma_signal.empty:
                return 0
            bollinger_signal = BollingerBands(close=serie, window=20).bollinger_mavg()
            bollinger_signal.fillna(method='ffill', inplace=True)
            bollinger_signal.fillna(method='bfill', inplace=True)
            print('bollinger_signal' + bollinger_signal.__str__())
            if bollinger_signal.values is not None or bollinger_signal.empty:
                return 0

            rsi_signal = RSIIndicator(close=serie, window=14).rsi()

            rsi_signal.fillna(method='ffill', inplace=True)
            rsi_signal.fillna(method='bfill', inplace=True)
            print('rsi_signal' + rsi_signal.__str__())
            if rsi_signal.values is not None or rsi_signal.empty:
                return 0

            signal_df = pd.DataFrame({
                'rsi': rsi_signal.values,
                'macd': macd_signal.values,

                'sma': sma_signal.values,
                'bollinger': bollinger_signal.values,
                'buy_or_sell_signal': np.where(sma_signal > bollinger_signal, 1, -1)
            })
            print(signal_df.head())
            print(signal_df.tail())

            signal_df = signal_df.dropna()

            signal_df = signal_df.reset_index(drop=True)

            # Instantiate the imputer with a strategy (mean, median, etc.)
            imputer = SimpleImputer(strategy='mean')
            x0 = np.array([signal_df['rsi'].values, signal_df['macd'].values, signal_df['sma'].values,
                           signal_df['bollinger'].values],
                          signal_df['buy_or_sell_signal']).T  # Number of features in the dataset

            # Fit and transform the data

            if data.values is not None or signal_df.values is not None:
                print('Shape of x0:', x0.shape)
                print('data values errors:', data.values.shape)

                return 0

            X = imputer.fit_transform(x0)

            y = signal_df[
                'buy_or_sell_signal']  # Assuming you have a column named 'buy_or_sell_signal' in your DataFrame

            print("Shape of X:", X.shape)
            print("Shape of y:", y.shape)
            print("Shape of df:", signal_df.shape)
            print("Number of samples in df:", len(signal_df))

            x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            model = self.model  # RandomForestClassifier(random_state=42, n_estimators=1000, max_depth=10)
            model.fit(x_train, y_train)
            y_pred = self.model.predict(x_test)

            print(confusion_matrix(y_test, y_pred))
            print(classification_report(y_test, y_pred))

            accuracy = model.score(x_train, y_train)
            scores = cross_val_score(model, x_train, y_train, cv=5)  # 5-fold cross-validation
            print("Cross-validation scores:", scores)
            print("Mean Accuracy:", scores.mean())
            print("Standard Deviation:", scores.std())
            print("Accuracy on Training Set:", scores.mean())
            print("Accuracy on Test Set:", scores.mean())
            print("Accuracy on Training Set:", scores.mean())
            return scores
        else:
            print('Data is not available')
            return 0

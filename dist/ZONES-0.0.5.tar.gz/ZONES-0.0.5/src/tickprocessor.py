import os
from datetime import datetime, timedelta
from os.path import join, exists
from random import random

import pandas as pd
from matplotlib import pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split, cross_val_score
from ta.trend import MACD

from src.DwxClient import DwxClient


def order_select(i, MODE_HISTORY):
    return 1


def order_magic_number():
    return 1


def order_profit():
    return 0


def get_signal(symbol, time_frame, df0):
    df = pd.DataFrame(columns=['close',
                               '12-day EMA',
                               '26-day EMA',
                               'MACD',
                               "Signal Line",
                               'Signal'])
    df['close'] = df0['close']
    data = df

    data['12-day EMA'] = data['close'].ewm(span=12, adjust=False).mean()
    data['26-day EMA'] = data['close'].ewm(span=26, adjust=False).mean()
    data['MACD'] = data['12-day EMA'] - data['26-day EMA']
    data["Signal Line"] = data['MACD'].ewm(span=9, adjust=False).mean()
    data['Signal'] = 0  # Initialize signal column
    data.loc[data['MACD'] > data["Signal Line"], 'Signal'] = 1  # Buy signal
    data.loc[data['MACD'] < data["Signal Line"], 'Signal'] = -1  # Sell signal

    plt.figure(figsize=(12, 6), dpi=100)
    plt.plot(data['close'], label='Close Price')
    plt.plot(data[data['Signal'] == 1]['close'], '^', markersize=10, color='g', label='Buy Signal')
    plt.plot(data[data['Signal'] == -1]['close'], 'v', markersize=10, color='r', label='Sell Signal')
    plt.title('MACD Strategy ' + symbol + ' ' + time_frame)
    plt.xlabel('Date')

    plt.ylabel('Price')
    plt.legend()

    data['Returns'] = data['close'].pct_change()
    data['Strategy Returns'] = data['Signal'].shift(1) * data['Returns']
    total_strategy_returns = data['Strategy Returns'].sum()
    print("Total Strategy Returns:", total_strategy_returns)
    data['Next Signal'] = data['Signal'].shift(-1)

    data.dropna(inplace=True)
    x = data[['12-day EMA', '26-day EMA', 'MACD', "Signal Line"]]
    y = data['Strategy Returns']

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=42)
    model = RandomForestClassifier(random_state=42, n_estimators=1000, max_depth=10)
    model.fit(x_train, y_train)

    y_pre = model.predict(x_test)

    print(classification_report(y_test, y_pre))
    print(model.score(x_test, y_test))
    print(model.score(x_train, y_train))
    scores = cross_val_score(model, x_train, y_train, cv=5)  # 5-fold cross-validation
    print("Cross-validation scores:", scores)

    return total_strategy_returns


class TickProcessor(object):
    X_train: object
    y_train: object
    X_test: object
    y_test: object
    model = None

    def __init__(self,
                 sleep_delay=0.005,  # 5 ms for time.sleep()
                 max_retry_command_seconds=10,  # retry to send to commend for 10 seconds if not successful.
                 verbose=True, db=None, metatrader_dir_path: str = ''
                 ):
        self.metatrader_dir_path = metatrader_dir_path
        self.takeprofit = 0.01
        self.signal = None
        self.stoploss = 0.01
        self.bar_data = None
        self.orderprofit_ = 0
        self.profits = 0
        self.MM_Martingale_Start = 0.01
        self.MM_Martingale_LossFactor = 2
        self.MM_Martingale_RestartLoss = True
        self.MM_Martingale_RestartProfit = True
        self.MM_Martingale_ProfitFactor = 4
        self.MagicNumber = 0

        if not exists(join(self.metatrader_dir_path, 'DWX', "setting.csv")):
            os.makedirs(join(self.metatrader_dir_path, 'DWX', "setting.csv"))
        # read path with admin privileges
        self.settings_file_path = join(self.metatrader_dir_path, 'DWX', "setting.csv")
        self.Ris = pd.read_csv(self.settings_file_path)
        self.Risk = self.Ris['Risk']
        self.MODE_TICKSIZE = None
        self.MODE_TICKVALUE = None
        self.MM_Martingale_RestartProfits = True
        self.MODE_HISTORY = None
        self.SELECT_BY_POS = None
        self.MM_Position = pd.read_csv(join(self.metatrader_dir_path, "DWX", "setting.csv"))
        self.MM_PositionSizing = self.MM_Position['Position_size']
        self.MM_Martingale_RestartLosses = None
        self.MM_Martingale_Mode = None
        self.MODE_MINLOT = 0.01
        self.MODE_MAXLOT = 1000000
        self.profit_ = None
        self.MM_Martingale_Start = pd.read_csv(join(self.metatrader_dir_path,
                                                    "DWX", "setting.csv"))['MM_Martingale_ProfitFactor']
        self.MM_Martingale_Mode = pd.read_csv(join(self.metatrader_dir_path,
                                                   "DWX", "setting.csv"))['MM_Martingale_LossFactor']
        self.MM_Martingale_RestartProfit = pd.read_csv(join(self.metatrader_dir_path,
                                                            'DWX', "setting.csv"))['MM_Martingale_RestartProfit']
        self.MM_Martingale_RestartLoss = pd.read_csv(join(metatrader_dir_path,
                                                          'DWX', "setting.csv"))['MM_Martingale_RestartLoss']
        self.MM_Martingale_RestartLosses = pd.read_csv(join(metatrader_dir_path,
                                                            'DWX', "setting.csv"))['MM_Martingale_RestartLosses']
        self.MM_Martingale_RestartProfits = pd.read_csv(join(metatrader_dir_path,
                                                             'DWX', "setting.csv"))['MM_Martingale_RestartProfits']
        self.MM_Martingale_ProfitFactor = pd.read_csv(join(metatrader_dir_path,
                                                           'DWX', "setting.csv"))['MM_Martingale_ProfitFactor']

        self.order_id = 0
        self.history_data_df = pd.DataFrame()
        self.signal_on_tick = None
        self.historic_trades = None
        self.historic_trades_df = None
        self.lot_size = 0.01
        self.order_type = 'buy'

        self.bar_data_count = None
        self.bar_data_count = 0
        self.metatrader_dir_path: str = metatrader_dir_path

        self.tick_data = None
        self.symbol = 'EURUSD'

        self.bid = 0.0

        self.ask = 0.0
        self.db = db
        self.da = None
        self.bar_data_df = pd.DataFrame(columns=['time', 'symbol', 'time_frame', 'open', 'high', 'low', 'close',
                                                 'volume'])
        self.verbose = verbose
        self.sleep_delay = sleep_delay
        self.max_retry_command_seconds = max_retry_command_seconds

        self.last_open_time = datetime.utcnow()
        self.last_modification_time = datetime.utcnow()

        self.dwx = DwxClient(self, metatrader_dir_path=self.metatrader_dir_path, verbose=verbose, db=self.db)
        self.time_frame = self.dwx.time_frame
        self.dwx.start()

        # account information is stored in self.dwx.account_info.
        print("Account info:", self.dwx.account_info.__str__())
        # subscribe to tick data:

        print("Subscribing to tick data...")

        symbols = []

        for i in self.dwx.symbols:

            da = i
            if i == da:
                symbols.append(i)

        self.dwx.subscribe_symbols(symbols)
        symbo = [[]]
        for i in symbols:
            symbo = [i, 'H1']
        self.dwx.subscribe_symbols_bar_data([symbo])

        # self.dwx.subscribe_symbols_bar_data([['EURUSD', 'H1'], ['GBPUSD', 'H1'], ['AUDCHF', 'M5']])
        # request historic data:
        end = datetime.utcnow()
        start = datetime.utcnow() - timedelta(days=60)  # last 30

        # last 60 days
        self.dwx.get_historic_data(self.dwx.symbol, self.dwx.time_frame, start, end)

    def on_tick(self, symbol: str = '', time_frame='H1', bid: float = 0.0, ask: float = 0.0):

        now = datetime.utcnow()
        print('on_tick:', now, symbol, bid, ask)
        self.tick_data = pd.DataFrame([{'time': now, 'bid  ': bid, '  ask': ask}])
        self.order_type = self.dwx.settings['order_type']
        time_frame = 'H1'
        # Load historical market data into a DataFrame
        self.db.cur.exec_driver_sql(
            "CREATE TABLE IF NOT EXISTS bar_data ( _id INT PRIMARY KEY AUTO_INCREMENT,"
            "time datetime,"
            "symbol varchar(10),"
            "time_frame varchar(5),"
            "open double,"
            "high double,"
            "low double,"
            "close double,"
            "volume INT"
            ");")

        for symb in self.dwx.symbols:
            if symb == symbol:
                df = self.bar_data.loc[self.bar_data['symbol'] == symb]

                self.bar_data_count += 0
                predicted_signal = MACD(close=df['close'], window_sign=26, window_fast=12, fillna=False).macd_signal()

                print(df.head())
                print(df.tail())

                self.signal_on_tick = self.get_signal_on_tick(df['close'],
                                                              predicted_signal=1)

                # GENERATE TRADE SIGNAL ON TICK

                self.bid = bid
                self.ask = ask
                self.symbol = symbol
                self.order_id = random() * 10000800
                lot = self.get_lot_size(symbol, stop_loss=self.stoploss)

                print(df.head())
                print(df.tail())

                if self.signal_on_tick == 1:
                    self.signal_on_tick = 0
                    self.order_type = 'buystop'
                    self.dwx.open_order(
                        symbol=symbol,
                        order_type=self.order_type,
                        lots=lot,
                        price=ask,
                        stop_loss=ask - self.stoploss * ask,
                        take_profit=ask + self.takeprofit * ask,
                        magic=random() * self.lot_size,
                        comment=self.order_type + '@' + symbol + '@' + str(bid) + '@' + str(
                            ask) + datetime.utcnow().strftime(
                            '%Y-%m-%d %H:%M:%S'),
                        expiration=0)

                elif self.signal_on_tick == 3 or self.signal_on_tick == -1:

                    self.signal_on_tick = 0
                    self.order_type = 'sellstop'
                    self.dwx.open_order(
                        symbol=symbol,
                        order_type=self.order_type,
                        lots=lot,
                        price=bid,
                        stop_loss=bid + self.stoploss * bid,
                        take_profit=bid - self.takeprofit * bid,
                        magic=random() * self.lot_size,
                        comment=self.order_type + '@' + symbol + '@' + str(bid) + '@' + str(
                            ask) + datetime.utcnow().strftime(
                            '%Y-%m-%d %H:%M:%S'),
                        expiration=0)
                elif self.signal_on_tick == 2 or self.signal_on_tick == -2:  # Close buy order
                    self.signal_on_tick = 0
                    self.dwx.close_orders_by_symbol(symbol=symbol)

                else:
                    self.signal_on_tick = 0
                    self.dwx.modify_order(
                        ticket=self.order_id,
                        lots=self.lot_size,
                        price=self.bid,
                        stop_loss=self.ask + self.stoploss * self.bid,
                        take_profit=self.ask - self.takeprofit * self.bid,
                        expiration=0
                    )
                self.dwx.modify_order(
                    ticket=self.order_id,
                    lots=self.lot_size,
                    price=self.ask,
                    stop_loss=self.bid - self.stoploss * self.ask,
                    take_profit=self.bid + self.takeprofit * self.ask,
                    expiration=0)

    def on_bar_data(self, symbol: str = '', time_frame: str = '', time_: str = '', _open: float = 0.1,
                    high: float = 0.1, low: float = 0.1, close: float = 0.1, volume: float = 0.1):

        self.bar_data_count += 1
        if self.verbose:
            self.bar_data = pd.DataFrame(['time', 'symbol', 'time_frame', 'open', 'high', 'low', 'close', 'volume'])
            self.bar_data['symbol'] = symbol
            self.bar_data['time'] = time_
            self.bar_data['time_frame'] = time_frame
            self.bar_data['open'] = _open
            self.bar_data['high'] = high
            self.bar_data['low'] = low
            self.bar_data['close'] = close
            self.bar_data['volume'] = volume

            self.bar_data.to_csv(join(self.dwx.metatrader_dir_path + "//DWX", 'bar_data.csv'), index=True, header=True)
            print('bar_data number' + str(self.bar_data_count) + " " + str(self.bar_data))
            self.dwx.server_status['bar_data_count'] = self.bar_data_count
            self.dwx.server_status['bar_data'] = self.bar_data

    def on_historic_data(self, symbol: str = '', time_frame: str = '', data: list = None):

        history = pd.DataFrame(data, columns=['time', 'symbol', 'time_frame', 'open', 'high', 'low', 'close', 'volume'])

        if self.verbose:
            history['symbol'] = symbol
            history['time_frame'] = time_frame
            history.to_csv(join(self.dwx.metatrader_dir_path + "//DWX", 'historic_data.csv'), index=True, header=True)
            print('historic number' + str(self.bar_data_count) + " " + str(history))

    def on_historic_trades(self, symbol: str = '', time_frame: str = '', trades: list = None):

        print(f'historic_trades: {len(self.dwx.historic_trades)}')
        self.dwx.historic_trades = pd.DataFrame(trades, columns=['time', 'time_frame', 'symbol', 'order_id',
                                                                 'price', 'amount', 'comment', 'expiration',
                                                                 'order_type', 'stoploss', 'takeprofit'])
        if self.verbose:
            self.dwx.historic_trades['symbol'].values = symbol
            self.dwx.historic_trades['time_frame'].values = time_frame
            self.dwx.historic_trades.to_csv(join(self.dwx.metatrader_dir_path + "DWX", 'historic_trades.csv'),

                                            index=False, header=True)

            print('historic_trades number' + str(self.bar_data_count) + " " + str(self.dwx.historic_trades))

    def on_message(self, message):

        if message['type'] == 'ERROR':
            print(message['type'], '|', message['error_type'], '|', message['description'])
            self.dwx.server_status['server_status'] = 'ERROR'
            self.dwx.server_status['error_type'] = message['error_type']
            self.dwx.server_status['description'] = message['description']
        elif message['type'] == 'INFO':
            print(message['type'], '|', message['message'])
            self.dwx.server_status['server_status'] = 'OK'
            self.dwx.server_status['message'] = message['message']

    # triggers when an order is added or removed, not when only modified.
    def on_order_event(self):
        print(f'on_order_event. open_orders: {len(self.dwx.open_orders)} open orders')
        self.dwx.server_status['open_orders'] = len(self.dwx.open_orders)
        self.dwx.server_status['server_status'] = 'OK'

    def get_lot_size(self, sym: str = '', stop_loss=0.01):
        lot = 0.01
        if self.dwx.settings['moneymanagement'].values == 'MARTINGALE':
            lot = self.martingale(sym)
            print(f'martingale lot: {lot}')
        if self.dwx.settings['moneymanagement'].values == 'POSITION_SIZE':
            lot = self.position_size(sym)
            print(f'position_size lot: {lot}')
        if self.dwx.settings['moneymanagement'].values == 'RISK_PERCENT_PER_TRADE':
            lot = self.risk_percent(sym, stoploss=stop_loss)

            print(f'risk_percent lot: {lot}')
        return lot * 10

    #
    #
    # //+------------------------------------------------------------------+
    # //|                  POSITION SIZE                                                |
    # //+------------------------------------------------------------------+
    def position_size(self, sym):
        max_lot = self.market_info(sym, self.MODE_MAXLOT)
        min_lot = self.market_info(sym, self.MODE_MINLOT)
        lots = self.account_balance() / self.MM_PositionSizing
        if lots > max_lot:
            lots = max_lot
        if lots < min_lot:
            lots = min_lot
        return lots

    #
    #
    # //+------------------------------------------------------------------+
    #   //|                RiskPercent                                                  |
    # //+------------------------------------------------------------------+
    def risk_percent(self, sym: str = '',
                     stoploss=0.01):  # Risk % per trade, SL = relative Stop Loss to calculate risk

        if stoploss <= 0:
            stoploss = 100

        max_lot = self.market_info(sym, self.MODE_MAXLOT)
        min_lot = self.market_info(sym, self.MODE_MINLOT)
        tickvalue = self.market_info(sym, self.MODE_TICKVALUE)
        ticksize = self.market_info(sym, self.MODE_TICKSIZE)
        lots = ((self.Risk * self.account_balance()) / stoploss + self.account_balance()) / 1000000
        if lots <= 0:
            lots = 0.01
        if lots > max_lot:
            lots = max_lot
        if lots < min_lot:
            lots = min_lot
        return lots

    #
    # //+------------------------------------------------------------------+
    #   //|                                                                  |
    # //+------------------------------------------------------------------+
    def select_last_history_trade(self, sym=''):  # //SelectLastHistoryTrade

        last_order = -1
        total = self.orders_history_total()
        for i in range(0, total):

            if not order_select(i, self.MODE_HISTORY):
                continue
            if order_magic_number() == self.MagicNumber:
                last_order = i
                break

        return last_order >= 0

    #
    # //+------------------------------------------------------------------+
    #   //|                                                                  |
    # //+------------------------------------------------------------------+
    def bo_profit(self, ticket):  # //Binary Options profit
        total: int = self.orders_history_total()
        for i in range(0, total):
            if not order_select(i, self.MODE_HISTORY):
                continue
            if (self.string_substr(self.order_comment(), 0, 2) == "BO" and
                    self.string_find(self.order_comment(), "#" + self.integer_to_string(ticket) + " ") >= 0):
                return order_profit()
            return 0

    def consecutive_pl(self, sym, profits: float = 0.0, n: int = 0):  # //ConsecutivePL

        count = 0
        total: int = self.orders_history_total()
        for i in range(0, total):

            if not order_select(i, self.MODE_HISTORY):
                continue
            if self.order_symbol() == sym and order_magic_number() == self.MagicNumber:

                self.orderprofit_ = profits
                self.profit_ = self.bo_profit(self.order_ticket())
                if not self.profits and ((self.orderprofit_ + self.profit_) >= 0) or \
                        (self.profits and self.orderprofit_ + self.profit_ <= 0):
                    break
            count += 1
        return count >= n

    #
    #
    #
    # //+------------------------------------------------------------------+
    #   //|                   Martingale                                               |
    # //+------------------------------------------------------------------+
    def martingale(self, sym):  # //martingale / anti-martingale

        lots = self.MM_Martingale_Start = 0.01
        max_lot = self.market_info(sym, self.MODE_MAXLOT)
        min_lot = self.market_info(sym, self.MODE_MINLOT)
        if self.select_last_history_trade(sym):
            orderprofit = order_profit()
            orderlots = self.order_lots()
            boprofit = self.bo_profit(self.order_ticket())
            if orderprofit + boprofit > 0 and not self.MM_Martingale_RestartProfit:
                lots = orderlots * self.MM_Martingale_ProfitFactor
            else:
                if orderprofit + boprofit < 0 and not self.MM_Martingale_RestartLoss:
                    lots = orderlots * self.MM_Martingale_LossFactor
                else:
                    if orderprofit + boprofit == 0:
                        lots = orderlots
            if self.consecutive_pl(sym, self.MM_Martingale_RestartLosses):
                lots = self.MM_Martingale_Start
        if self.consecutive_pl(sym, self.MM_Martingale_RestartProfits):
            lots = self.MM_Martingale_Start
        if lots > max_lot:
            lots = max_lot
        if lots < min_lot:
            lots = min_lot

        return random() * lots * 10

    def market_info(self, sym, mode_max):

        if mode_max == self.MODE_MAXLOT:
            return self.MODE_MAXLOT

        if mode_max == self.MODE_MINLOT:
            return self.MODE_MINLOT

        if mode_max == self.MODE_TICKSIZE:
            return self.MODE_TICKSIZE

        if mode_max == self.MODE_TICKVALUE:
            return self.MODE_TICKVALUE

        return 0

    def account_balance(self):

        return pd.read_csv(join(self.dwx.metatrader_dir_path + "DWX", 'account_balance.csv'), index_col=0).iloc[:, ]

    def orders_history_total(self):
        count = 0
        for c in self.dwx.open_orders:
            count = len(c[1])

        return count

    def order_symbol(self):
        return self.dwx.symbol

    def order_ticket(self):
        return 1

    def order_lots(self):
        return self.dwx.open_orders.iloc[:, 1]

    def order_comment(self):
        return self.dwx.open_orders.iloc[:, 2]

    def integer_to_string(self, ticket):
        return str(ticket)

    def string_find(self, param, param1):
        return param.find(param1)

    def string_substr(self, param, param1, param2):
        return param[param1:param2]

    def get_signal_on_tick(self, param, predicted_signal: int):
        if predicted_signal > 0:
            if param > 0:
                return 1
            else:
                return 0
        elif predicted_signal < 0:
            if param < 0:
                return -1
            else:
                return 0
        else:
            return 0
        pass
